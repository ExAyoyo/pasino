python main.py
sleep 500000000000
sh start.sh